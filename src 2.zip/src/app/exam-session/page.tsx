

function ExamSessionPage() {
  return (
    <div>
      <h1>Exam Session</h1>
      <p>Exam session details will be displayed here.</p>
    </div>
  );
}
export default ExamSessionPage;