

function Admin() {
  return (
    <div>
      <h1>Admin Dashbaord</h1>
    </div>
  );
}

export default Admin;